# LAN of DOOM Map Settings plugin
SourceMod plugin for CS:GO automatically setting the LAN of DOOM's preferred map
settings on map load.

# Building
Check out the repository and run the ``./build.sh`` script.

# Installation
Copy ``lan_of_doom_map_settings.smx`` to your server's ``css/cstrike/addons/sourcemod/plugins`` directory.
